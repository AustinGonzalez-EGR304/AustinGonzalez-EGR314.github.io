#include <Arduino.h>

HardwareSerial MyUART(1);

// UART pins
const int RX_PIN = 16;
const int TX_PIN = 17;

// Protocol
const uint8_t START_BYTE = 'Z';
const uint8_t END_BYTE   = 'Y';

// board ID
const char MY_ID = 'G';

// Receive buffer
uint8_t receiveBuffer[10];   // sender, receiver, type
int bufferIndex = 0;
bool receiving = false;

struct Packet {
  char sender;
  char receiver;
  uint8_t type;
};

// ----------------------
// Send packet
// ----------------------
void sendPacket(char sender, char receiver, uint8_t type)
{
  uint8_t buffer[5];
 MyUART.write('A');
  buffer[0] = START_BYTE;
  buffer[1] = sender;
  buffer[2] = receiver;
  buffer[3] = type;
  buffer[4] = END_BYTE;
  MyUART.write(buffer, 5);
   MyUART.write('B');
}

// ----------------------
// Camera control
// ----------------------
void moveCameraPreset(uint8_t type)
{
  switch (type)
  {
    case 1:
      Serial.println("Moving to preset 1");
      break;

    case 2:
      Serial.println("Moving to preset 2");
      break;

    case 3:
      Serial.println("Moving to preset 3");
      break;

    default:
      Serial.print("Unknown preset: ");
      Serial.println(type);
      break;
  }
}

// ----------------------
// Handle packet
// ----------------------
void handlePacket(Packet pkt)
{
  Serial.println("\nReceived Packet:");
  Serial.print("Sender: ");
  Serial.println(pkt.sender);
  Serial.print("Receiver: ");
  Serial.println(pkt.receiver);
  Serial.print("Type: ");
  Serial.println(pkt.type);

  // ERROR CASE: message from yourself
  if (pkt.sender == MY_ID)
  {
    Serial.println("Error: Packet from myself. Discarding.");
    return;
  }

  // If message is for me
  if (pkt.receiver == MY_ID)
  {
    Serial.println("Message is for me.");
    moveCameraPreset(pkt.type);
  }
  else
  {
    // Forward downstream
    sendPacket(pkt.sender, pkt.receiver, pkt.type);
  }
}

// ----------------------
// Setup
// ----------------------
void setup()
{
  Serial.begin(115200);
  MyUART.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);

  Serial.println("Camera subsystem ready.");
}

// ----------------------
// Loop
// ----------------------
void loop()
{
  while (MyUART.available())
  {
    uint8_t byteIn = MyUART.read();

    // Wait for START
    if (!receiving)
    {
      if (byteIn == START_BYTE)
      {
        receiving = true;
        bufferIndex = 0;
      }
    }
    else
    {
      // If END detected -> process packet
      if (byteIn == END_BYTE)
      {
        if (bufferIndex == 3) // sender, receiver, type
        {
          Packet pkt;
          pkt.sender   = receiveBuffer[0];
          pkt.receiver = receiveBuffer[1];
          pkt.type     = receiveBuffer[2];

          handlePacket(pkt);
        }
        else
        {
          Serial.println("Error: malformed packet");
        }

        receiving = false;
      }
      else
      {
        // Store bytes
        if (bufferIndex < 10)
        {
          receiveBuffer[bufferIndex++] = byteIn;
        }
        else
        {
          Serial.println("Error: overflow");
          receiving = false;
        }
      }
    }
  }
}