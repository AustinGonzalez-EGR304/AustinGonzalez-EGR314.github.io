#include <Wire.h>

const uint8_t TMAG_ADDR = 0x78;   // TMAG5273C1 detected address
const int SDA_PIN = 22;
const int SCL_PIN = 23;

const int LED_PIN = 4;

// Register addresses
const uint8_t REG_DEVICE_CONFIG_1 = 0x00;
const uint8_t REG_DEVICE_CONFIG_2 = 0x01;
const uint8_t REG_SENSOR_CONFIG_1 = 0x02;
const uint8_t REG_SENSOR_CONFIG_2 = 0x03;
const uint8_t REG_X_MSB = 0x12;

int16_t xOffset = 0;
int16_t yOffset = 0;
int16_t zOffset = 0;

HardwareSerial MyUART(1);

//Timer
int delTime = 0;

// UART pins
const int RX_PIN = 16;
const int TX_PIN = 17;

// Protocol
const uint8_t START_BYTE = 'Z';
const uint8_t END_BYTE   = 'Y';

// board ID
const char MY_ID = 'G';

// Receive buffer
uint8_t receiveBuffer[10];   // sender, receiver, type
int bufferIndex = 0;
bool receiving = false;

struct Packet {
  char sender;
  char receiver;
  uint8_t type;
};

void writeReg(uint8_t reg, uint8_t value) {
  Wire.beginTransmission(TMAG_ADDR);
  Wire.write(reg);
  Wire.write(value);
  Wire.endTransmission();
}

void sendPacket(char sender, char receiver, uint8_t type)
{
  uint8_t buffer[5];
 MyUART.write('A');
  buffer[0] = START_BYTE;
  buffer[1] = sender;
  buffer[2] = receiver;
  buffer[3] = type;
  buffer[4] = END_BYTE;
  MyUART.write(buffer, 5);
   MyUART.write('B');
}

void moveCameraPreset(uint8_t type)
{
  switch ((char)type)
  {
    case 'U':
      Serial.println("Moving to preset 1");
      digitalWrite(21,HIGH);
      delay(500);
      digitalWrite(21,LOW);
      break;

    case 'D':
      Serial.println("Moving to preset 2");
      digitalWrite(19,HIGH);
      delay(500);
      digitalWrite(19,LOW);
      break;

    case 'C':
      Serial.println("Moving to preset 3");
      digitalWrite(18,HIGH);
      delay(500);
      digitalWrite(18,LOW);
      break;

    default:
      Serial.print("Unknown preset: ");
      Serial.println(type);
      break;
  }
}

void handlePacket(Packet pkt)
{
  Serial.println("\nReceived Packet:");
  Serial.print("Sender: ");
  Serial.println(pkt.sender);
  Serial.print("Receiver: ");
  Serial.println(pkt.receiver);
  Serial.print("Type: ");
  Serial.println(pkt.type);

  // ERROR CASE: message from yourself
  if (pkt.sender == MY_ID)
  {
    Serial.println("Error: Packet from myself. Discarding.");
    return;
  }
  if (pkt.receiver == 'X')
  {
   Serial.println("ROLLCALL.");
  digitalWrite(18,HIGH);
  delay(100);
  digitalWrite(18,LOW);
  digitalWrite(19,HIGH);
  delay(100);
  digitalWrite(19,LOW);
  digitalWrite(21,HIGH);
  delay(100);
  digitalWrite(21,LOW);
  }
  // If message is for me
  if (pkt.receiver == MY_ID)
  {
    Serial.println("Message is for me.");
    moveCameraPreset(receiveBuffer[3]);
  }
  else
  {
    // Forward downstream
    sendPacket(pkt.sender, pkt.receiver, pkt.type);
  }

  memset(receiveBuffer,0,sizeof(receiveBuffer));


}

void readRegs(uint8_t startReg, uint8_t *buf, uint8_t len) {
  Wire.beginTransmission(TMAG_ADDR);
  Wire.write(startReg);
  Wire.endTransmission(false);

  Wire.requestFrom((int)TMAG_ADDR, (int)len);

  uint8_t i = 0;
  while (Wire.available() && i < len) {
    buf[i++] = Wire.read();
  }
}

int16_t combineBytes(uint8_t msb, uint8_t lsb) {
  return (int16_t)((msb << 8) | lsb);
}

void readXYZ(int16_t &x, int16_t &y, int16_t &z) {
  uint8_t data[6] = {0};

  readRegs(REG_X_MSB, data, 6);

  x = combineBytes(data[0], data[1]);
  y = combineBytes(data[2], data[3]);
  z = combineBytes(data[4], data[5]);
}

void setup() {
  Serial.begin(9600);
  MyUART.begin(9600, SERIAL_8N1, RX_PIN, TX_PIN);
  delay(1000);
  pinMode(18,OUTPUT);
  pinMode(19,OUTPUT);
  pinMode(21,OUTPUT);
  Serial.println("Camera subsystem ready.");

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Wire.begin(SDA_PIN, SCL_PIN);
  Wire.setClock(100000);

  writeReg(REG_DEVICE_CONFIG_1, 0x05);
  writeReg(REG_DEVICE_CONFIG_2, 0x12);
  writeReg(REG_SENSOR_CONFIG_1, 0x70);
  writeReg(REG_SENSOR_CONFIG_2, 0x00);

  delay(20);

  long sumX = 0;
  long sumY = 0;
  long sumZ = 0;
  const int samples = 50;

  for (int i = 0; i < samples; i++) {
    int16_t x, y, z;
    readXYZ(x, y, z);
    sumX += x;
    sumY += y;
    sumZ += z;
    delay(10);
  }

  xOffset = sumX / samples;
  yOffset = sumY / samples;
  zOffset = sumZ / samples;

  Serial.println("TMAG5273 ready");
  Serial.print("Offsets -> X: ");
  Serial.print(xOffset);
  Serial.print(" Y: ");
  Serial.print(yOffset);
  Serial.print(" Z: ");
  Serial.println(zOffset);
}

void loop() {
  if(delTime < millis())
  {
    int16_t x, y, z;
    readXYZ(x, y, z);

    int16_t xRel = x - xOffset;
    int16_t yRel = y - yOffset;
    int16_t zRel = z - zOffset;

    if (abs(xRel) < 20) xRel = 0;
    if (abs(yRel) < 20) yRel = 0;
    if (abs(zRel) < 20) zRel = 0;

    if (abs(yRel) > 1000) {
      digitalWrite(LED_PIN, HIGH);
    } else {
      digitalWrite(LED_PIN, LOW);
    }

    Serial.print("Raw X: ");
    Serial.print(x);
    Serial.print("  Y: ");
    Serial.print(y);
    Serial.print("  Z: ");
    Serial.print(z);

    Serial.print("   |   Zeroed X: ");
    Serial.print(xRel);
    Serial.print("  Y: ");
    Serial.print(yRel);
    Serial.print("  Z: ");
    Serial.println(zRel);
    delTime = millis() + 3000;
  }




 while (MyUART.available())
  {
    uint8_t byteIn = MyUART.read();

    // Wait for START
    if (!receiving)
    {
      if (byteIn == START_BYTE)
      {
        receiving = true;
        bufferIndex = 0;
      }
    }
    else
    {
      // If END detected -> process packet
      if (byteIn == END_BYTE)
      {
        receiving = false;
        if (bufferIndex >= 3) // sender, receiver, type
        {
          Packet pkt;
          pkt.sender   = receiveBuffer[0];
          pkt.receiver = receiveBuffer[1];
          pkt.type     = receiveBuffer[2];
          for(int e = 0; e < bufferIndex; e++){
            Serial.println((int8_t)receiveBuffer[e]);
          }
          handlePacket(pkt);
          
        }
        else
        {
          Serial.println("Error: malformed packet");
        }

        
      }
      else
      {
        // Store bytes
        if (bufferIndex < 10)
        {
          receiveBuffer[bufferIndex++] = byteIn;
        }
        else
        {
          Serial.println("Error: overflow");
          receiving = false;
        }
      }
    }
  }
}
